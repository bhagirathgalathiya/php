<!DOCTYPE html>
<html>
<head>  
     <link rel="stylesheet" href="useof.css">
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js'></script>
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script src="jquerysession.js"></script>
    <script>
   $(document).ready(function() {
   

   
   function isUser() {
        $.session.set('login', 'yes');
        window.location.href = "requests.php";
        
    }

    function notUser() {
        alert('Username Or Password is Wrong');
    }
    

    $('#submit').click(function() {
        var $uname = $('#uname').val();
        var $pass = $('#pass').val();
        var $results = " ";
        $.ajax({
            url: 'checkUser.php',
            data: {
                uname: $uname,
                pass: $pass
            },
            type: 'POST',
            cache: false,
            success: function(data) {
                var k = data;
                if( data == '1')
                {
                   isUser();
                }
                else
                {
                   notUser();     
                }
                
            },
            error: function() {
                alert('error');
            }
        });

    });



});
</script>
</head>
<body>
<div class="wrapper">
  <div id="formContent">
    <h2 class="active">Admin site for report</h2>
    <div class="fadeIn first">
      <img src="rmc.png" id="icon" alt="User Icon" />
    </div>
    </br>
      <input type="text" id="uname" class="fadeIn second" name="login" placeholder="User Name">
      </br>
      <input type="text" id="pass" class="fadeIn third" name="login" placeholder="password">
      </br>
      <input type="button"  id="submit" class="fadeIn fourth" value="Log In">
  </div>
</div>
</body>
</html>