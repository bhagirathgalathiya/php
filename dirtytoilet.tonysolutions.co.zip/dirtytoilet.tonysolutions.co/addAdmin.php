<?php
    require_once 'connection.php';
     session_start();
     if(!(isset($_SESSION['islogin']) && !empty($_SESSION['islogin']))) {
           header("Location: http://dirtytoilet.tonysolutions.co");
        }
    if ($conn->connect_error) 
    {
        die("Connection failed: " .$conn->connect_error );
        exit();
    }
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $sql = "INSERT INTO `admins`( `uname`, `password`, `flag`) VALUES ('$uname','$pass','1') ";
    //echo $sql;
    if ($conn->query($sql) === TRUE) 
     {
        echo "Admin Added";
     } 
     else 
     {
        echo "Error: " . $sql . "<br>" . $conn->error;
     } 
     $conn->close();
 
?>