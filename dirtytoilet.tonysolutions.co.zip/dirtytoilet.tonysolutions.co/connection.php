<?php
    
    $dbhost = "fdb19.awardspace.net";
    $dbunm = "3286146_ssiprajkot";
    $dbpass = "3286146_ssiprajkot";
    $dbname = "3286146_ssiprajkot";
    $conn = new mysqli();
    $conn = mysqli_connect($dbhost,$dbunm,$dbpass,$dbname);


?>