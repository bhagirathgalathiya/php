<?php
    require_once 'connection.php';
    date_default_timezone_set('Asia/Kolkata');
    define('UPLOAD_PATH', 'uploads/');
    $response = array();
    $photo_link = " ";
    if ($conn->connect_error) 
    {
        //die("Connection failed: " .$conn->connect_error );
        $response['error'] = true;
        $response['message'] =$conn->connect_error;
        exit();
    }
    if (isset($_FILES['pic']['name']))
    {
       try
       {
                move_uploaded_file($_FILES['pic']['tmp_name'], UPLOAD_PATH . $_FILES['pic']['name']);
                $response['error'] = false;
                $photo_link = UPLOAD_PATH . $_FILES['pic']['name'];
                
                
                $time =  date('Y-m-d H:i:s');
                $uname = $_POST['name'];
                $unumber = $_POST['number'];
                $uaddress = $_POST['location'];
                $description = $_POST['discription'];
                $email = $_POST['email'];
                
                $sql = "INSERT INTO `dirtytoilet_report`(`uemail`,`uname`, `unumber`, `photo_link`, `uaddress`, `description`, `flag`, `complain_time`) VALUES ('$email','$uname','$unumber','$photo_link','$uaddress','$description','1','$time')";
                //echo $sql;
                if ($conn->query($sql) === TRUE) 
                {
                        $response['error'] = false;
                        $response['message'] = "Reported Successfully";
                } 
                else 
                {
                //echo "Error: " . $sql . "<br>" . $conn->error;
                        $response['error'] = true;
                        $response['message'] =  $conn->error;
                }

    
         }
         catch(Exception $e)
         {
             $response['error'] = true;
             $response['message'] = 'Could not upload file';
         }
    
    }
    else
    {
            $response['error'] = true;
            $response['message'] = "Required params not available";
            exit();
    }
    header('Content-Type: application/json');
    echo json_encode($response);
    $conn->close();
 
?>