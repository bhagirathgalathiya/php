<?php
     require_once 'connection.php';
     if ($conn->connect_error) 
     {
             die("Connection failed: " . $conn->connect_error);
     }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css'>
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js'></script>
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script>
        $(document).ready(function()
        {

            $('.delete_data').click(function() {
                var $id_data = $(this).closest('tr').find('#rid').val();
                //alert($id_data);
                $.ajax({
                    url:'deleteData.php',
                    data:{rid:$id_data},
                    type:'POST',
                    cache:false,
                    success:function(data){
                        alert(data);
                    },
                    error:function()
                    {
                        alert('error');
                    }
                });
                $(this).parent().parent().remove();
            });

            
        });
    </script>
</head>
<body>
</br></br></br>
<div class='container'>         
  <table class='table table-condensed'>
    <thead>
      <tr>
        <th>id</th>
        <th>Photo</th>
        <th>Email</th>
        <th>Name</th>
        <th>Number</th>
        <th>Address</th>
        <th>Discription</th>
        <th>Time</th>
        <th>Done Time</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
     $sql = "SELECT * FROM `dirtytoilet_report` WHERE `flag` = '0' ";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
         // output data of each row
         $i =1;
         while($row = $result->fetch_assoc()) {
           
           ?>
        <tr>
          <td id='email' ><?php echo $i; ?></td>
          <td id='photo' ><img src='<?php echo $row["photo_link"]; ?>' border=3 height=100 width=100></img></td>
          <td id='email' ><?php echo $row["uemail"]; ?></td>
          <td id='name' ><?php echo $row["uname"]; ?></td>
          <td id='number' ><?php echo $row["unumber"]; ?></td>
          <td id='address' ><?php echo $row["uaddress"]; ?></td>
          <td id='discription' ><?php echo $row["description"]; ?></td>
          <td id='reporttime' ><?php echo $row["complain_time"]; ?></td>
          <td id='donetime' ><?php echo $row["solved_time"]; ?></td>
          <td><button type='button' class='btn btn-danger delete_data'>Delete</button></td>
          <td><input type='hidden' id='rid' name='rid' value='<?php echo $row["id"]; ?>'></td>
        </tr>
          <?php
          $i = $i +1;
         }
         }
      else {
         echo "0 results";
     }
     $conn->close();
?>
    </tbody>
  </table>
</div>

</body>
</html>