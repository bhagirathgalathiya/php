<?php
            require_once 'connection.php';
            session_start();
            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            }
            $uname = $_POST['uname'];
            $pass = $_POST['pass'];
            $sql = "SELECT * FROM `admins` WHERE  `password` = '$pass' AND `uname` = '$uname' AND  `flag` = '1' ";
            //echo $sql;
            $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo 1;
        }
        else 
        {
            echo 0;
        }
        $conn->close();
        
?>