<?php
    require_once 'connection.php';
    date_default_timezone_set('Asia/Kolkata');
    if ($conn->connect_error) 
    {
        die("Connection failed: " .$conn->connect_error );
    }
    $id = $_POST['rid'];
    $time =  date('Y-m-d H:i:s');
    $sql = "DELETE FROM `dirtytoilet_report` WHERE `id` = '$id'  ";       
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
     } else {
        echo "Error updating record: " . $conn->error;
     }
     $conn->close();
 
?>