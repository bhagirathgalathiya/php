<?php
    require_once 'connection.php';
    date_default_timezone_set('Asia/Kolkata');
    if ($conn->connect_error) 
    {
        die("Connection failed: " .$conn->connect_error );
        exit();
    }
    $id = $_POST['rid'];
    $time =  date('Y-m-d H:i:s');
    $sql = "UPDATE `dirtytoilet_report` SET `flag`= '0' ,`solved_time`= '$time' WHERE `id` = '$id'  ";       
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
     } else {
        echo "Error updating record: " . $conn->error;
     }
     $conn->close();
 
?>