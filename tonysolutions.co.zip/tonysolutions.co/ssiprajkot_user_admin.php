<?php
    require_once 'connection.php';
    date_default_timezone_set('Asia/Kolkata');
    define('UPLOAD_PATH', 'uploads/');
    $response = array();
    $photo_link = " ";
    if ($conn->connect_error) 
    {
        //die("Connection failed: " .$conn->connect_error );
        $response['error'] = true;
        $response['message'] =$conn->connect_error;
        exit();
    }
    if (isset($_POST['uemail']))
    {
       try
       {
                                
                $time =  date('Y-m-d H:i:s');
                $email = $_POST['uemail'];
                
                $sql = "INSERT INTO `users`( `email`, `re_time`) VALUES ('$email','$time')";
                //echo $sql;
                if ($conn->query($sql) === TRUE) 
                {
                        $response['error'] = false;
                        $response['message'] = "Done";
                } 
                else 
                {
                //echo "Error: " . $sql . "<br>" . $conn->error;
                        $response['error'] = true;
                        $response['message'] =  $conn->error;
                }

    
         }
         catch(Exception $e)
         {
             $response['error'] = true;
             $response['message'] = 'Could not upload file';
         }
    
    }
    else
    {
            $response['error'] = true;
            $response['message'] = "parameater not sended";
            exit();
    }
    header('Content-Type: application/json');
    echo json_encode($response);
    $conn->close();
 
?>